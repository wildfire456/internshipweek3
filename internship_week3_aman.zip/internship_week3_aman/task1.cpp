#include <SFML/Graphics.hpp>
#include <iostream>
#include <string>

using namespace sf;
using namespace std;

Font opensans;
Text display;
string prompt = "Sprite loaded.";

Sprite rat;
Texture tex1;

int main()
{
    tex1.loadFromFile("rat.png");
    rat.setTexture(tex1);
    rat.setScale(0.195, 0.21);
     rat.setPosition(250, 200);

    opensans.loadFromFile("open-sans/OpenSans-Regular.ttf");
    display.setFont(opensans);
    display.setString(prompt);
    display.setPosition(260, 350);
   display.setCharacterSize(24);
           display.setFillColor(sf::Color::Black); 
 
    RenderWindow window(sf::VideoMode(700, 700), "Sprite");

    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
            if (Keyboard::isKeyPressed(Keyboard::X))
                window.close();
        }

        window.clear(sf::Color::White); 

         window.draw(rat);
        window.draw(display);

        window.display(); 
    }

    return 0;
}
