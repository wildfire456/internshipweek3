#include <string>
#include <SFML/Graphics.hpp>
#include <iostream>

using namespace sf;
using namespace std;




  Font opensans;
  Text display;
  string prompt = " Press F to change font\n Press C to change Text color\n Press S to change size";
  
  
 
int main()
{     
    int color =1;
    int fonttype=1;
    int sizetype=1;

    bool sizechange=0;
    bool colorchange=0;
    bool fontchange =0;
     opensans.loadFromFile("open-sans/OpenSans-Regular.ttf");
     display.setFont(opensans);
      sf::RenderWindow window(sf::VideoMode(700, 700), "Window");
      window.clear(sf::Color::White);
       display.setString(prompt);

          display.setPosition(160,350);
         display.setCharacterSize(24); 
    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();

        
        }
            if (Keyboard::isKeyPressed(Keyboard::X))
            {
          window.close();
          return 0;
            }
          if (Keyboard::isKeyPressed(Keyboard::C) && colorchange==0)
          {
            color++;

            if (color == 8)
            color =1;
            colorchange=1;
          }

          if (!Keyboard::isKeyPressed(Keyboard::C))
           {
            colorchange=0;
           }
     
        if (color==1)
        display.setFillColor(sf::Color::Blue); 

        else if (color==2)
        display.setFillColor(sf::Color::Black); 

        else if (color==3)
        display.setFillColor(sf::Color::Red); 

        else if (color==4)
          display.setFillColor(sf::Color::Yellow); 
       
        else if (color==5)
        display.setFillColor(sf::Color::Magenta);

        else if (color==6)
       display.setFillColor(sf::Color::Cyan); 

        else if (color==7)
       display.setFillColor(sf::Color::Green); 


        if (Keyboard::isKeyPressed(Keyboard::F) && fontchange==0)
          {
            fonttype++;

            if (fonttype == 6)
            fonttype =1;
            fontchange=1;
          }
             
               
        if (fonttype==1 && fontchange==1)
            opensans.loadFromFile("open-sans/OpenSans-Regular.ttf");

            else  if (fonttype==2 && fontchange==1)
            opensans.loadFromFile("open-sans/HappySwirly.ttf");

             else  if (fonttype==3 && fontchange==1)
            opensans.loadFromFile("open-sans/Inflate.ttf");

             else  if (fonttype==4 && fontchange==1)
            opensans.loadFromFile("open-sans/ShadeBlue.ttf");

             else  if (fonttype==5 && fontchange==1)
            opensans.loadFromFile("open-sans/CookieCrisp.ttf");

          if (!Keyboard::isKeyPressed(Keyboard::F))
           {
            fontchange=0;
           }
   
        
             // size change

        if (Keyboard::isKeyPressed(Keyboard::S) && sizechange==0)
          {
            sizetype++;

            if (sizetype == 6)
            sizetype =1;
            sizechange=1;
          }
             
               
        if (sizetype==1 && sizechange==1)
           {
  
           display.setPosition(160,350);
           display.setCharacterSize(24); 
           }


        else if (sizetype==2 && sizechange==1)
           {
  
           display.setPosition(160,350);
           display.setCharacterSize(26); 
           }

            else if (sizetype==3 && sizechange==1)
           {
  
           display.setPosition(160,350);
           display.setCharacterSize(28); 
           }
        
            else if (sizetype==4 && sizechange==1)
           {
  
           display.setPosition(160,350);
           display.setCharacterSize(30); 
           }
           else if (sizetype==5 && sizechange==1)
           {
  
           display.setPosition(160,350);
           display.setCharacterSize(32); 
           }



            

          if (!Keyboard::isKeyPressed(Keyboard::S))
           {
            sizechange=0;
           }
   
        
        

     
     
        window.draw(display);
        
        window.display();
         window.clear(sf::Color::White);
        
      }

    return 0;
}
