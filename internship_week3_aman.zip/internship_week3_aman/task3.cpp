#include <SFML/Graphics.hpp>
#include <iostream>
#include <string>

using namespace sf;
using namespace std;

Font opensans;
Text display, display2;
string prompt = "no input";
string prompt2 = "ANIMATION TEST";




int main()
{
  Texture tex1, bgtex; 
 tex1.loadFromFile("skull.png");
 bgtex.loadFromFile("bg.jpg");
IntRect sourcesprite(0,128,64,64);
   Sprite sprite (tex1, sourcesprite);
   Sprite bg;
   bg.setScale(0.51,0.7);
   bg.setTexture(bgtex);
   Clock clock;

   string direction = "down";
   bool input =0;
    sprite.setScale(2.0, 2.0);
   
     sprite.setPosition(154, 270);
 
    opensans.loadFromFile("open-sans/OpenSans-ExtraBold.ttf");
    display.setFont(opensans);
    display.setString(prompt);
    display.setPosition(164, 400);
   display.setCharacterSize(24);

    display2.setFont(opensans);
    display2.setString(prompt2);
    display2.setPosition(224, 10);
   display2.setCharacterSize(32);

           display.setFillColor(sf::Color::Red); 
  
    RenderWindow window(sf::VideoMode(700, 700), "Animation");

    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
            if (Keyboard::isKeyPressed(Keyboard::X))
                window.close();
        }

        if (Keyboard::isKeyPressed(Keyboard::W))
                {
                    input = 1;
                    direction = "up";
                    prompt = "W pressed";
                    display.setFillColor(sf::Color::Green); 
                    display.setString(prompt);
                }
        else if (Keyboard::isKeyPressed(Keyboard::S))
                {
                    input = 1;
                    direction = "down";
                     prompt = "S pressed";
                    display.setFillColor(sf::Color::Green); 
                    display.setString(prompt);
                }

         else if (Keyboard::isKeyPressed(Keyboard::A))
                {
                    input = 1;
                    direction = "left";
                     prompt = "A pressed";
                     display.setFillColor(sf::Color::Green); 

                    display.setString(prompt);
                }
        
         else if (Keyboard::isKeyPressed(Keyboard::D))
                {
                    input = 1;
                     direction = "right";
                    display.setFillColor(sf::Color::Green); 
                     prompt = "D pressed";
                    display.setString(prompt);
                }

            else if (!Keyboard::isKeyPressed(Keyboard::R) && !Keyboard::isKeyPressed(Keyboard::A) && !Keyboard::isKeyPressed(Keyboard::S)  && !Keyboard::isKeyPressed(Keyboard::W) ) 
             { 
                if(input==1)
                 {
                     
                    
                        sourcesprite.left = 0;
                        sprite.setTextureRect(sourcesprite);
                        prompt = "no input";
                        display.setFillColor(sf::Color::Red); 
                        display.setString(prompt);

                 }
                input = 0;
             }


              if (clock.getElapsedTime().asSeconds() > 0.1f && input ==1)
                 {

                if(direction == "up")
                  {
                    sourcesprite.top = 0;
                  }

                 else  if(direction == "left")
                  {
                    sourcesprite.top = 64;
                  }

                   else  if(direction == "down")
                  {
                    sourcesprite.top = 128;
                  }

                     else  if(direction == "right")
                  {
                    sourcesprite.top = 192;
                  }
                    
                    if (sourcesprite.left == 512)
                        sourcesprite.left = 0;
                    else
                        sourcesprite.left += 64;

                


                sprite.setTextureRect(sourcesprite);
                clock.restart();
                }

 
        window.clear(sf::Color::White); 
          window.draw(bg);
         // cout<<direction<<endl;
             window.draw(sprite);
        window.draw(display);
         window.draw(display2);
      
        window.display(); 
       
    }

    return 0;
}

